package com.elderly.elderly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElderlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
