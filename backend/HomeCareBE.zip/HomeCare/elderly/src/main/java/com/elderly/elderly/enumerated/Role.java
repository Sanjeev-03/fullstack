package com.elderly.elderly.enumerated;


public enum Role {
    USER, ADMIN;
}